
import stone.Grinder;
import stone.GrinderBench;
import stone.Stone;

public class Exo4 {

    public static void main(String[] args) {
        Stone s = Stone.makeHugeStone();
        Grinder g = new myGrinder();
        GrinderBench.benchmark(g, 4, s);
    }

}