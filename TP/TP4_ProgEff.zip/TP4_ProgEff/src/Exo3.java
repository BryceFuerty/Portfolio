import stone.AbstractGrinderTest;
import stone.Grinder;

public class Exo3 extends AbstractGrinderTest {


    /**
     * Returns the grinder under test.
     *
     * @return An object implementing interface Grinder
     */
    @Override
    protected Grinder makeGrinder() {
        return new myGrinder();
    }
}




