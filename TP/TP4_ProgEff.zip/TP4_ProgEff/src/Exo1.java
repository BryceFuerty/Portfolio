import stone.Stone;

public class Exo1 {

    public static void main (String[] args) {
        Stone petitePierre = Stone.makeSmallStone();
        System.out.println(petitePierre);
        Stone moitiePierre = petitePierre.split();
        System.out.println(petitePierre);
        System.out.println(moitiePierre);


    }
}
