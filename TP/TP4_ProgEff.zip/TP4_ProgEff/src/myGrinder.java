
import stone.Grinder;
import stone.Stone;

import java.util.ArrayList;
import java.util.Collection;

public class myGrinder implements Grinder {


    /**
     * Breaks a stone into fragments which can individually go through a hole of
     * a given diameter. A fragment which is small enough should not be broken
     * anymore.
     *
     * @param stone    The stone to grind
     * @param diameter The diameter (in centimeter) of the hole used to check if a
     *                 stone is small enough
     * @return All the stones resulting of the fragmentations
     */
    @Override
    public Collection<Stone> grind(Stone stone, int diameter) {
        ArrayList<Stone> collection = new ArrayList<Stone>() ;

        collection.add(stone);

        for (int indice = 0 ; indice < collection.size(); indice++) {
            while (collection.get(indice).diameter() > diameter) {
                collection.add(collection.get(indice).split());
                }
            }
        return collection;
    }

}
