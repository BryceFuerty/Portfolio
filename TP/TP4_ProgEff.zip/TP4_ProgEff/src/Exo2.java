import stone.Stone;

public class Exo2 {

    public static void main (String[] args) {
        Stone Grandepierre = Stone.makeBigStone();
        Stone GrandePierreMoitie = Grandepierre.split();
        int i = 0;
        while (Grandepierre.diameter() > 5 || GrandePierreMoitie.diameter() > 5) {
            GrandePierreMoitie = Grandepierre.split();
            i = i+1 ;
        }

        System.out.println("La pierre a étée cassée");
        System.out.println(i + " Fois ");


    }

}
